import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  boolean,
  varchar,
  decimal,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  phone: varchar("phone", { length: 50 }),
  referralCode: varchar("referral_code", { length: 50 }).unique(),
  referredBy: varchar("referred_by", { length: 50 }),
  hasPurchased: boolean("has_purchased").default(false),
  pdfAccessGranted: boolean("pdf_access_granted").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  email: varchar("email", { length: 255 }).notNull(),
  name: varchar("name", { length: 255 }),
  phone: varchar("phone", { length: 50 }),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: varchar("status", { length: 50 }).default("pending"), // pending | paid | failed
  prodamusOrderId: varchar("prodamus_order_id", { length: 255 }),
  referralCode: varchar("referral_code", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow(),
  paidAt: timestamp("paid_at"),
});

export const referralPayouts = pgTable("referral_payouts", {
  id: serial("id").primaryKey(),
  referrerEmail: varchar("referrer_email", { length: 255 }).notNull(),
  referrerCode: varchar("referrer_code", { length: 50 }).notNull(),
  orderId: integer("order_id").references(() => orders.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: varchar("status", { length: 50 }).default("pending"), // pending | paid
  createdAt: timestamp("created_at").defaultNow(),
});

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Order = typeof orders.$inferSelect;
export type NewOrder = typeof orders.$inferInsert;
export type ReferralPayout = typeof referralPayouts.$inferSelect;
