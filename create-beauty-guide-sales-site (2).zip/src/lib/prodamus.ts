import crypto from "crypto";

const PRODAMUS_URL = process.env.PRODAMUS_FORM_URL || "https://demo.payform.ru/";
const PRODAMUS_KEY = process.env.PRODAMUS_SECRET_KEY || "";

export interface ProdamusProduct {
  name: string;
  price: string;
  quantity: string;
  sku?: string;
}

export interface ProdamusLinkParams {
  orderId: string;
  customerEmail?: string;
  customerPhone?: string;
  customerName?: string;
  products: ProdamusProduct[];
  urlSuccess?: string;
  urlReturn?: string;
  urlNotification?: string;
  customerExtra?: string;
}

// Рекурсивная сортировка данных (как в PHP ksort)
function sortRecursive(data: Record<string, unknown> | unknown[]): unknown {
  if (Array.isArray(data)) {
    return data.map((item) =>
      typeof item === "object" && item !== null
        ? sortRecursive(item as Record<string, unknown>)
        : String(item)
    );
  }
  const sorted: Record<string, unknown> = {};
  Object.keys(data as Record<string, unknown>)
    .sort()
    .forEach((key) => {
      const val = (data as Record<string, unknown>)[key];
      if (typeof val === "object" && val !== null) {
        sorted[key] = sortRecursive(val as Record<string, unknown>);
      } else {
        sorted[key] = String(val);
      }
    });
  return sorted;
}

// Создание HMAC подписи для верификации вебхука
export function createSignature(data: Record<string, unknown>): string {
  const sorted = sortRecursive(data);
  const json = JSON.stringify(sorted);
  return crypto.createHmac("sha256", PRODAMUS_KEY).update(json).digest("hex");
}

// Верификация вебхука от Продамуса
export function verifyWebhook(
  data: Record<string, unknown>,
  receivedSign: string
): boolean {
  if (!PRODAMUS_KEY) return true; // В dev режиме без ключа пропускаем
  const expected = createSignature(data);
  return expected === receivedSign;
}

// Формирование URL для оплаты через Продамус
export function buildProdamusUrl(params: ProdamusLinkParams): string {
  const queryParams: Record<string, string> = {
    do: "link",
    order_id: params.orderId,
    callbackType: "json",
    payments_limit: "1",
  };

  if (params.customerEmail) {
    queryParams["customer_email"] = params.customerEmail;
  }
  if (params.customerPhone) {
    queryParams["customer_phone"] = params.customerPhone;
  }
  if (params.customerName) {
    queryParams["customer_extra"] = params.customerName;
  }
  if (params.urlSuccess) {
    queryParams["urlSuccess"] = params.urlSuccess;
  }
  if (params.urlReturn) {
    queryParams["urlReturn"] = params.urlReturn;
  }
  if (params.urlNotification) {
    queryParams["urlNotification"] = params.urlNotification;
  }

  // Добавляем продукты
  params.products.forEach((product, index) => {
    queryParams[`products[${index}][name]`] = product.name;
    queryParams[`products[${index}][price]`] = product.price;
    queryParams[`products[${index}][quantity]`] = product.quantity;
    if (product.sku) {
      queryParams[`products[${index}][sku]`] = product.sku;
    }
  });

  const qs = new URLSearchParams(queryParams).toString();
  return `${PRODAMUS_URL}?${qs}`;
}
