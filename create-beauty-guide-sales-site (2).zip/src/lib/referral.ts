import { customAlphabet } from "nanoid";

const nanoid = customAlphabet("ABCDEFGHJKLMNPQRSTUVWXYZ23456789", 8);

export function generateReferralCode(): string {
  return nanoid();
}

export const PRODUCT_PRICE = 1499;
export const REFERRAL_PERCENT = 0.45; // 45%
export const REFERRAL_AMOUNT = Math.round(PRODUCT_PRICE * REFERRAL_PERCENT); // 674 ₽
