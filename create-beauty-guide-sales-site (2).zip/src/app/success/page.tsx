"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";

const PDF_GOOGLE_DRIVE_LINK =
  "https://drive.google.com/file/d/1to9l6uoaXlbtY3yNzcaB_a0SZ6AVcQsr/view?usp=drive_link";

interface OrderInfo {
  email?: string;
  name?: string;
  status?: string;
}

function SuccessPageContent() {
  const searchParams = useSearchParams();
  const orderId = searchParams.get("orderId");
  const [order, setOrder] = useState<OrderInfo | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (orderId) {
      // Небольшая задержка для обработки вебхука
      setTimeout(() => {
        setLoading(false);
        setOrder({ status: "paid" });
      }, 2000);
    } else {
      setLoading(false);
    }
  }, [orderId]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-16"
      style={{ background: "linear-gradient(135deg, #fff0f7 0%, #fff8f0 100%)" }}>
      
      {loading ? (
        <div className="text-center">
          <div className="text-6xl mb-4 animate-pulse">💅</div>
          <div className="text-xl text-gray-600">Обрабатываем платёж...</div>
        </div>
      ) : (
        <div className="max-w-lg w-full bg-white rounded-3xl shadow-xl p-10 text-center">
          {/* Success Icon */}
          <div className="w-24 h-24 mx-auto mb-6 rounded-full flex items-center justify-center text-5xl"
            style={{ background: "linear-gradient(135deg, #ff2d8a20, #ff6b6b20)" }}>
            🎉
          </div>

          <h1 className="text-3xl font-black text-gray-900 mb-3">
            Оплата прошла!
          </h1>
          <p className="text-gray-600 mb-6">
            Поздравляем с покупкой! Твой 30-дневный контент-план для бьюти-мастера готов 💅✨
          </p>

          {/* Download Button */}
          <div className="bg-gradient-to-r from-pink-500 to-red-400 rounded-2xl p-1 mb-6">
            <a
              href={PDF_GOOGLE_DRIVE_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-white rounded-xl px-6 py-4 font-bold text-pink-600 hover:bg-pink-50 transition text-lg"
            >
              📥 Скачать PDF гайд
            </a>
          </div>

          <div className="bg-pink-50 rounded-2xl p-5 mb-6 text-left">
            <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
              <span>📩</span> Что дальше?
            </h3>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-green-500 mt-0.5">✓</span>
                Кнопка выше ведёт прямо на PDF файл — нажми и скачай
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-500 mt-0.5">✓</span>
                Ссылка также отправлена на твой email
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-500 mt-0.5">✓</span>
                Войди в личный кабинет, чтобы получить реферальную ссылку и зарабатывать
              </li>
            </ul>
          </div>

          {/* Referral CTA */}
          <div className="border border-pink-200 rounded-2xl p-5 mb-6">
            <div className="text-2xl mb-2">🤝</div>
            <h3 className="font-bold text-gray-900 mb-1">Зарабатывай на рекомендациях!</h3>
            <p className="text-sm text-gray-600 mb-4">
              Войди в личный кабинет — получи реферальную ссылку и зарабатывай{" "}
              <strong className="text-pink-600">674 ₽ (45%)</strong> с каждой продажи
            </p>
            <Link
              href="/dashboard"
              className="btn-primary block text-white font-bold py-3 rounded-xl text-center text-sm"
            >
              Открыть личный кабинет →
            </Link>
          </div>

          <Link href="/" className="text-sm text-gray-400 hover:text-gray-600 transition">
            ← Вернуться на главную
          </Link>
        </div>
      )}
    </div>
  );
}

export default function SuccessPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-6xl animate-pulse">💅</div>
      </div>
    }>
      <SuccessPageContent />
    </Suspense>
  );
}
