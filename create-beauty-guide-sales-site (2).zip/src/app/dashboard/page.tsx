"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";

const PDF_GOOGLE_DRIVE_LINK =
  "https://drive.google.com/file/d/1to9l6uoaXlbtY3yNzcaB_a0SZ6AVcQsr/view?usp=drive_link";

interface UserData {
  user: {
    id: number;
    email: string;
    name: string | null;
    hasPurchased: boolean;
    pdfAccessGranted: boolean;
    referralCode: string | null;
    referralLink: string | null;
  };
  stats: {
    totalReferrals: number;
    paidReferrals: number;
    totalEarned: number;
    pendingAmount: number;
  };
}

export default function DashboardPage() {
  const [email, setEmail] = useState("");
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch(
        `/api/user?email=${encodeURIComponent(email)}`
      );
      const data = await res.json() as UserData & { error?: string };

      if (!res.ok) {
        setError(data.error || "Пользователь не найден");
        return;
      }

      setUserData(data);
    } catch {
      setError("Ошибка соединения");
    } finally {
      setLoading(false);
    }
  };

  const copyLink = () => {
    if (userData?.user.referralLink) {
      navigator.clipboard.writeText(userData.user.referralLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-pink-100 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-2xl">💅</span>
            <span className="font-bold text-gray-900">BeautyContent</span>
          </Link>
          {userData && (
            <button
              onClick={() => { setUserData(null); setEmail(""); }}
              className="text-sm text-gray-500 hover:text-gray-700 transition"
            >
              Выйти
            </button>
          )}
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-10">
        {!userData ? (
          // Login Form
          <div className="max-w-md mx-auto">
            <div className="bg-white rounded-3xl shadow-sm border border-pink-100 p-8 text-center">
              <div className="text-5xl mb-4">🔐</div>
              <h1 className="text-2xl font-black text-gray-900 mb-2">
                Личный кабинет
              </h1>
              <p className="text-gray-600 mb-8">
                Введи email, который ты использовала при покупке
              </p>

              <form onSubmit={handleLogin} className="space-y-4 text-left">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="your@email.com"
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:ring-2 focus:ring-pink-400 transition"
                  />
                </div>

                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-600 rounded-xl px-4 py-3 text-sm">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="btn-primary w-full text-white font-bold py-4 rounded-xl disabled:opacity-60"
                >
                  {loading ? "Загружаем..." : "Войти в кабинет →"}
                </button>
              </form>

              <div className="mt-6 pt-6 border-t border-gray-100">
                <p className="text-sm text-gray-500">
                  Ещё не купили гайд?{" "}
                  <Link href="/" className="text-pink-600 font-semibold hover:underline">
                    Купить за 1 499 ₽
                  </Link>
                </p>
              </div>
            </div>
          </div>
        ) : (
          // Dashboard
          <div className="space-y-6">
            {/* Welcome */}
            <div className="bg-white rounded-3xl shadow-sm border border-pink-100 p-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
                  style={{ background: "linear-gradient(135deg, #ff2d8a20, #ff6b6b20)" }}>
                  💅
                </div>
                <div>
                  <h1 className="text-2xl font-black text-gray-900">
                    Привет, {userData.user.name || userData.user.email}! 👋
                  </h1>
                  <p className="text-gray-500">{userData.user.email}</p>
                </div>
              </div>
            </div>

            {/* PDF Access */}
            <div className={`rounded-3xl shadow-sm border p-6 ${
              userData.user.pdfAccessGranted
                ? "bg-gradient-to-r from-pink-50 to-red-50 border-pink-200"
                : "bg-gray-50 border-gray-200"
            }`}>
              <h2 className="text-xl font-black text-gray-900 mb-4 flex items-center gap-2">
                <span>📥</span> Твой гайд
              </h2>

              {userData.user.pdfAccessGranted ? (
                <div>
                  <p className="text-gray-700 mb-4">
                    ✨ Доступ активирован! Нажми кнопку ниже, чтобы скачать PDF гайд.
                  </p>
                  <a
                    href={PDF_GOOGLE_DRIVE_LINK}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-primary inline-flex items-center gap-2 text-white font-bold px-8 py-4 rounded-xl text-lg"
                  >
                    📥 Скачать PDF гайд
                  </a>
                  <p className="text-sm text-gray-500 mt-3">
                    30-дневный контент-план для бьюти-мастера • 74 страницы
                  </p>
                </div>
              ) : (
                <div>
                  <p className="text-gray-600 mb-4">
                    Ты ещё не приобрела гайд. Купи его, чтобы получить доступ к PDF и реферальной программе.
                  </p>
                  <Link
                    href="/"
                    className="btn-primary inline-block text-white font-bold px-8 py-4 rounded-xl text-lg"
                  >
                    Купить гайд за 1 499 ₽ →
                  </Link>
                </div>
              )}
            </div>

            {/* Referral System */}
            {userData.user.pdfAccessGranted && (
              <>
                <div className="bg-white rounded-3xl shadow-sm border border-pink-100 p-6">
                  <h2 className="text-xl font-black text-gray-900 mb-4 flex items-center gap-2">
                    <span>🔗</span> Твоя реферальная ссылка
                  </h2>

                  <p className="text-gray-600 mb-4">
                    Делись этой ссылкой — и получай{" "}
                    <strong className="text-pink-600">674 ₽ (45%)</strong> за каждую покупку!
                  </p>

                  {userData.user.referralLink ? (
                    <div className="flex gap-3 mb-4">
                      <input
                        type="text"
                        value={userData.user.referralLink}
                        readOnly
                        className="flex-1 border border-gray-200 rounded-xl px-4 py-3 text-gray-700 text-sm bg-gray-50"
                      />
                      <button
                        onClick={copyLink}
                        className={`px-5 py-3 rounded-xl font-semibold transition text-sm flex-shrink-0 ${
                          copied
                            ? "bg-green-500 text-white"
                            : "bg-pink-100 text-pink-700 hover:bg-pink-200"
                        }`}
                      >
                        {copied ? "✓ Скопировано!" : "Копировать"}
                      </button>
                    </div>
                  ) : (
                    <div className="bg-gray-100 rounded-xl px-4 py-3 text-gray-400 text-sm mb-4">
                      Ссылка генерируется...
                    </div>
                  )}

                  <div className="bg-pink-50 rounded-2xl p-4">
                    <h3 className="font-bold text-gray-900 mb-2">Как делиться ссылкой:</h3>
                    <div className="grid sm:grid-cols-2 gap-2 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <span>📱</span> Отправить подруге в Telegram
                      </div>
                      <div className="flex items-center gap-2">
                        <span>📸</span> Опубликовать в Историях
                      </div>
                      <div className="flex items-center gap-2">
                        <span>💬</span> Поделиться в чате мастеров
                      </div>
                      <div className="flex items-center gap-2">
                        <span>📝</span> Написать пост в блоге
                      </div>
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    {
                      label: "Переходов по ссылке",
                      value: userData.stats.totalReferrals,
                      emoji: "👆",
                      color: "from-blue-50 to-indigo-50 border-blue-100",
                    },
                    {
                      label: "Успешных продаж",
                      value: userData.stats.paidReferrals,
                      emoji: "💳",
                      color: "from-green-50 to-emerald-50 border-green-100",
                    },
                    {
                      label: "Заработано (₽)",
                      value: `${userData.stats.totalEarned.toLocaleString("ru-RU")} ₽`,
                      emoji: "💰",
                      color: "from-pink-50 to-red-50 border-pink-100",
                    },
                    {
                      label: "К выплате (₽)",
                      value: `${userData.stats.pendingAmount.toLocaleString("ru-RU")} ₽`,
                      emoji: "🏦",
                      color: "from-yellow-50 to-orange-50 border-yellow-100",
                    },
                  ].map((stat, i) => (
                    <div
                      key={i}
                      className={`bg-gradient-to-br ${stat.color} border rounded-2xl p-5`}
                    >
                      <div className="text-3xl mb-2">{stat.emoji}</div>
                      <div className="text-2xl font-black text-gray-900 mb-1">
                        {stat.value}
                      </div>
                      <div className="text-sm text-gray-600">{stat.label}</div>
                    </div>
                  ))}
                </div>

                {/* Payout Info */}
                <div className="bg-white rounded-3xl shadow-sm border border-pink-100 p-6">
                  <h2 className="text-xl font-black text-gray-900 mb-4 flex items-center gap-2">
                    <span>💸</span> Выплаты
                  </h2>
                  <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4 mb-4">
                    <p className="text-yellow-800 text-sm">
                      💡 Для получения выплат напиши нам в{" "}
                      <a
                        href="https://t.me/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-bold underline"
                      >
                        Telegram
                      </a>{" "}
                      и укажи свой реферальный код:{" "}
                      <strong className="font-mono bg-yellow-100 px-2 py-0.5 rounded">
                        {userData.user.referralCode}
                      </strong>
                    </p>
                  </div>
                  <div className="text-sm text-gray-600">
                    <p className="mb-2">📋 Условия выплат:</p>
                    <ul className="space-y-1 text-gray-500">
                      <li>• Выплаты производятся на карту / СБП / ЮМани</li>
                      <li>• Минимальная сумма для вывода: 674 ₽ (1 продажа)</li>
                      <li>• Выплата в течение 3 рабочих дней после запроса</li>
                    </ul>
                  </div>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
