import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, orders } from "@/db/schema";
import { eq } from "drizzle-orm";

// Ручная активация доступа по ID заказа (для тестирования)
export async function POST(req: NextRequest) {
  const adminKey = req.headers.get("x-admin-key");
  if (adminKey !== process.env.ADMIN_SECRET_KEY && process.env.NODE_ENV === "production") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { orderId, email } = await req.json() as { orderId?: number; email?: string };

  if (email) {
    await db
      .update(users)
      .set({ hasPurchased: true, pdfAccessGranted: true })
      .where(eq(users.email, email.toLowerCase()));
    return NextResponse.json({ ok: true, message: "Доступ выдан по email" });
  }

  if (orderId) {
    const order = await db
      .select()
      .from(orders)
      .where(eq(orders.id, orderId))
      .then((rows) => rows[0] || null);

    if (!order) {
      return NextResponse.json({ error: "Заказ не найден" }, { status: 404 });
    }

    await db
      .update(orders)
      .set({ status: "paid", paidAt: new Date() })
      .where(eq(orders.id, orderId));

    if (order.userId) {
      await db
        .update(users)
        .set({ hasPurchased: true, pdfAccessGranted: true })
        .where(eq(users.id, order.userId));
    }

    return NextResponse.json({ ok: true, message: "Заказ активирован" });
  }

  return NextResponse.json({ error: "Нужен orderId или email" }, { status: 400 });
}
