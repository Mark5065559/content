import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, orders, referralPayouts } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const email = searchParams.get("email");

  if (!email) {
    return NextResponse.json({ error: "Email обязателен" }, { status: 400 });
  }

  const user = await db
    .select()
    .from(users)
    .where(eq(users.email, email.toLowerCase()))
    .then((rows) => rows[0] || null);

  if (!user) {
    return NextResponse.json({ error: "Пользователь не найден" }, { status: 404 });
  }

  // Получить рефералов
  const referrals = await db
    .select()
    .from(orders)
    .where(eq(orders.referralCode, user.referralCode || ""));

  const paidReferrals = referrals.filter((r) => r.status === "paid");

  // Получить выплаты
  const payouts = await db
    .select()
    .from(referralPayouts)
    .where(eq(referralPayouts.referrerCode, user.referralCode || ""));

  const totalEarned = payouts.reduce(
    (sum, p) => sum + parseFloat(p.amount || "0"),
    0
  );
  const pendingAmount = payouts
    .filter((p) => p.status === "pending")
    .reduce((sum, p) => sum + parseFloat(p.amount || "0"), 0);

  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || `https://${req.headers.get("host")}`;
  const referralLink = user.referralCode
    ? `${baseUrl}/?ref=${user.referralCode}`
    : null;

  return NextResponse.json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      hasPurchased: user.hasPurchased,
      pdfAccessGranted: user.pdfAccessGranted,
      referralCode: user.referralCode,
      referralLink,
    },
    stats: {
      totalReferrals: referrals.length,
      paidReferrals: paidReferrals.length,
      totalEarned,
      pendingAmount,
    },
  });
}
