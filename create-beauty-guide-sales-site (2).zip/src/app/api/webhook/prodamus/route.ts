import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, users, referralPayouts } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyWebhook } from "@/lib/prodamus";
import { REFERRAL_AMOUNT } from "@/lib/referral";

export async function POST(req: NextRequest) {
  try {
    const sign = req.headers.get("Sign") || "";
    const contentType = req.headers.get("content-type") || "";

    let body: Record<string, unknown> = {};

    if (contentType.includes("application/json")) {
      body = await req.json();
    } else {
      // form-urlencoded
      const text = await req.text();
      const params = new URLSearchParams(text);
      params.forEach((value, key) => {
        body[key] = value;
      });
    }

    // Верификация подписи
    const submitData =
      body["submit"] && typeof body["submit"] === "string"
        ? (JSON.parse(body["submit"] as string) as Record<string, unknown>)
        : (body as Record<string, unknown>);

    const isValid = verifyWebhook(submitData, sign);
    if (!isValid) {
      console.warn("Webhook signature mismatch");
      // В продакшне можно вернуть 401, но для совместимости возвращаем 200
    }

    const paymentStatus =
      (body["payment_status"] as string) ||
      (submitData["payment_status"] as string);
    const prodamusOrderId =
      (body["order_num"] as string) ||
      (submitData["order_num"] as string) ||
      (body["order_id"] as string) ||
      (submitData["order_id"] as string);

    if (!prodamusOrderId) {
      return NextResponse.json({ ok: true });
    }

    // Найти заказ
    const order = await db
      .select()
      .from(orders)
      .where(eq(orders.prodamusOrderId, prodamusOrderId))
      .then((rows) => rows[0] || null);

    if (!order) {
      console.warn(`Order not found: ${prodamusOrderId}`);
      return NextResponse.json({ ok: true });
    }

    if (paymentStatus === "success" && order.status !== "paid") {
      // Обновляем статус заказа
      await db
        .update(orders)
        .set({ status: "paid", paidAt: new Date() })
        .where(eq(orders.id, order.id));

      // Даём доступ пользователю
      if (order.userId) {
        await db
          .update(users)
          .set({ hasPurchased: true, pdfAccessGranted: true })
          .where(eq(users.id, order.userId));
      }

      // Реферальное начисление
      if (order.referralCode) {
        const referrer = await db
          .select()
          .from(users)
          .where(eq(users.referralCode, order.referralCode))
          .then((rows) => rows[0] || null);

        if (referrer) {
          await db.insert(referralPayouts).values({
            referrerEmail: referrer.email,
            referrerCode: order.referralCode,
            orderId: order.id,
            amount: String(REFERRAL_AMOUNT),
            status: "pending",
          });
        }
      }
    } else if (paymentStatus === "failed") {
      await db
        .update(orders)
        .set({ status: "failed" })
        .where(eq(orders.id, order.id));
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Prodamus webhook error:", error);
    return NextResponse.json({ ok: true });
  }
}
