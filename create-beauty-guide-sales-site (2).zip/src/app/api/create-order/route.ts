import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { buildProdamusUrl } from "@/lib/prodamus";
import { generateReferralCode, PRODUCT_PRICE } from "@/lib/referral";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, name, phone, referralCode } = body as {
      email: string;
      name: string;
      phone?: string;
      referralCode?: string;
    };

    if (!email || !name) {
      return NextResponse.json(
        { error: "Email и имя обязательны" },
        { status: 400 }
      );
    }

    // Найти или создать пользователя
    let user = await db
      .select()
      .from(users)
      .where(eq(users.email, email.toLowerCase()))
      .then((rows) => rows[0] || null);

    if (!user) {
      const newReferralCode = generateReferralCode();
      const inserted = await db
        .insert(users)
        .values({
          email: email.toLowerCase(),
          name,
          phone: phone || null,
          referralCode: newReferralCode,
          referredBy: referralCode || null,
        })
        .returning();
      user = inserted[0];
    }

    // Создать заказ
    const orderId = `ORDER-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;

    const insertedOrder = await db
      .insert(orders)
      .values({
        userId: user.id,
        email: email.toLowerCase(),
        name,
        phone: phone || null,
        amount: String(PRODUCT_PRICE),
        status: "pending",
        prodamusOrderId: orderId,
        referralCode: referralCode || null,
      })
      .returning();

    const order = insertedOrder[0];

    // Получить базовый URL
    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || `https://${req.headers.get("host")}`;

    // Формируем URL для оплаты
    const payUrl = buildProdamusUrl({
      orderId: orderId,
      customerEmail: email.toLowerCase(),
      customerPhone: phone,
      customerName: name,
      products: [
        {
          name: "30-дневный контент-план для бьюти-мастера (PDF гайд)",
          price: String(PRODUCT_PRICE),
          quantity: "1",
          sku: "beauty-content-plan-30",
        },
      ],
      urlSuccess: `${baseUrl}/success?orderId=${order.id}`,
      urlReturn: `${baseUrl}/?cancelled=1`,
      urlNotification: `${baseUrl}/api/webhook/prodamus`,
    });

    return NextResponse.json({ payUrl, orderId: order.id });
  } catch (error) {
    console.error("create-order error:", error);
    return NextResponse.json({ error: "Внутренняя ошибка сервера" }, { status: 500 });
  }
}
