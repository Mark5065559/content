"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import BuyModal from "@/components/BuyModal";

function HomePage() {
  const searchParams = useSearchParams();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [referralCode, setReferralCode] = useState<string | undefined>();

  useEffect(() => {
    const ref = searchParams.get("ref");
    if (ref) {
      setReferralCode(ref);
      localStorage.setItem("referralCode", ref);
    } else {
      const saved = localStorage.getItem("referralCode");
      if (saved) setReferralCode(saved);
    }

    const cancelled = searchParams.get("cancelled");
    if (cancelled) {
      // ничего не делаем, просто показываем страницу
    }
  }, [searchParams]);

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  return (
    <>
      <BuyModal
        isOpen={isModalOpen}
        onClose={closeModal}
        referralCode={referralCode}
      />

      {/* HEADER */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-md border-b border-pink-100">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl">💅</span>
            <span className="font-bold text-gray-900 text-lg">BeautyContent</span>
          </div>
          <button
            onClick={openModal}
            className="btn-primary text-white font-semibold px-5 py-2 rounded-full text-sm"
          >
            Купить за 1 499 ₽
          </button>
        </div>
      </header>

      <main>
        {/* HERO */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
          {/* Background */}
          <div className="absolute inset-0 gradient-hero opacity-10" />
          <div
            className="absolute inset-0 opacity-30"
            style={{
              backgroundImage: "url(/images/hero-bg.jpg)",
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-white/0 via-white/30 to-white" />

          <div className="relative z-10 max-w-4xl mx-auto px-4 text-center py-20">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-pink-50 border border-pink-200 text-pink-600 rounded-full px-4 py-2 text-sm font-medium mb-6">
              <span className="w-2 h-2 bg-pink-500 rounded-full animate-pulse" />
              PDF гайд • 74 страницы • Мгновенный доступ
            </div>

            {/* Heading */}
            <h1 className="text-5xl md:text-7xl font-black text-gray-900 mb-6 leading-tight">
              <span className="shimmer-text">30-дневный</span>
              <br />
              контент-план
              <br />
              <span className="text-gray-800">для бьюти-мастера</span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-600 mb-4 max-w-2xl mx-auto">
              Готовые посты, хэштеги, идеи для Reels и Stories —<br />
              <strong className="text-gray-900">всё уже продумано за тебя! ✨</strong>
            </p>

            <div className="flex flex-wrap justify-center gap-3 mb-10 text-sm text-gray-500">
              <span className="flex items-center gap-1 bg-white rounded-full px-3 py-1 shadow-sm border border-gray-100">
                💅 Маникюр
              </span>
              <span className="flex items-center gap-1 bg-white rounded-full px-3 py-1 shadow-sm border border-gray-100">
                🥀 Брови
              </span>
              <span className="flex items-center gap-1 bg-white rounded-full px-3 py-1 shadow-sm border border-gray-100">
                ✨ Ресницы
              </span>
              <span className="flex items-center gap-1 bg-white rounded-full px-3 py-1 shadow-sm border border-gray-100">
                💄 Макияж
              </span>
            </div>

            {/* CTA */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <button
                onClick={openModal}
                className="btn-primary pulse-glow text-white font-bold px-10 py-5 rounded-2xl text-xl shadow-lg"
              >
                Купить гайд за 1 499 ₽ →
              </button>
              <div className="text-sm text-gray-500">
                <div className="line-through text-gray-400">было 2 990 ₽</div>
                <div className="text-green-600 font-semibold">скидка 50% 🎉</div>
              </div>
            </div>

            {/* Trust */}
            <div className="mt-10 flex flex-wrap justify-center gap-6 text-sm text-gray-500">
              <span className="flex items-center gap-2">
                <span className="text-green-500">✓</span> Мгновенный доступ
              </span>
              <span className="flex items-center gap-2">
                <span className="text-green-500">✓</span> PDF на 74 страницы
              </span>
              <span className="flex items-center gap-2">
                <span className="text-green-500">✓</span> Безопасная оплата
              </span>
              <span className="flex items-center gap-2">
                <span className="text-green-500">✓</span> Навсегда ваш
              </span>
            </div>
          </div>
        </section>

        {/* PROBLEM */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-5xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-black text-gray-900 mb-4">
                Узнаёшь себя? 😔
              </h2>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  emoji: "😩",
                  text: "Садишься вечером за телефон, смотришь в экран — и в голове абсолютная пустота",
                },
                {
                  emoji: "🤔",
                  text: "Каждый день мучаешься: «Что сегодня запостить?» — и откладываешь на потом",
                },
                {
                  emoji: "📉",
                  text: "Контент выходит редко или хаотично, аудитория не растёт, клиентов мало",
                },
                {
                  emoji: "⏰",
                  text: "Времени на придумывание контента нет — руки заняты работой целый день",
                },
                {
                  emoji: "😕",
                  text: "Видишь, как другие мастера ведут блог красиво и системно — и завидуешь",
                },
                {
                  emoji: "💸",
                  text: "Платишь SMM-специалисту, а результата всё нет — деньги на ветер",
                },
              ].map((item, i) => (
                <div
                  key={i}
                  className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 card-hover"
                >
                  <div className="text-4xl mb-3">{item.emoji}</div>
                  <p className="text-gray-700">{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* SOLUTION */}
        <section className="py-20 bg-white">
          <div className="max-w-5xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-black text-gray-900 mb-4">
                Решение — готовый контент-план! 🚀
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Открываешь нужный день — и точно знаешь: что публиковать, что
                писать, какие хэштеги ставить. Всё уже продумано за тебя.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                {[
                  { emoji: "📅", title: "30 готовых дней контента", desc: "Полный месяц публикаций расписан по дням — никакого «что постить?»" },
                  { emoji: "✍️", title: "Готовые тексты для постов", desc: "Не нужно ничего придумывать — просто вставь свои фото и опубликуй" },
                  { emoji: "#️⃣", title: "Хэштеги для каждой ниши", desc: "Маникюр, брови, ресницы, макияж — отдельные наборы хэштегов" },
                  { emoji: "🎬", title: "Идеи для Reels и Stories", desc: "Вирусные форматы, которые приносят новых подписчиков и клиентов" },
                  { emoji: "📌", title: "5 контент-пилларов", desc: "Система, при которой аудитория не устаёт — разный контент чередуется" },
                ].map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="text-3xl flex-shrink-0">{item.emoji}</div>
                    <div>
                      <div className="font-bold text-gray-900">{item.title}</div>
                      <div className="text-gray-600 text-sm">{item.desc}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="relative">
                <div className="float-animation">
                  <div
                    className="rounded-3xl overflow-hidden shadow-2xl border-4 border-pink-100"
                    style={{ background: "linear-gradient(135deg, #ff2d8a, #f5c842)" }}
                  >
                    <img
                      src="/images/guide-preview.jpg"
                      alt="PDF гайд — 30-дневный контент-план"
                      className="w-full object-cover opacity-90"
                    />
                    <div className="absolute inset-0 flex items-end p-6">
                      <div className="bg-white/90 backdrop-blur rounded-2xl p-4 w-full">
                        <div className="font-black text-gray-900 text-lg">30-дневный контент-план</div>
                        <div className="text-gray-600 text-sm">для бьюти-мастера • 74 страницы</div>
                        <div className="flex gap-2 mt-2 flex-wrap">
                          {["💅 Маникюр", "🥀 Брови", "✨ Ресницы", "💄 Макияж"].map(t => (
                            <span key={t} className="text-xs bg-pink-50 text-pink-600 rounded-full px-2 py-0.5">{t}</span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* Decoration */}
                <div className="absolute -top-4 -right-4 bg-yellow-400 text-gray-900 font-black rounded-full w-16 h-16 flex items-center justify-center text-xs text-center leading-tight shadow-lg">
                  74<br/>стр.
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* WHAT'S INSIDE */}
        <section className="py-20" style={{ background: "linear-gradient(135deg, #fff0f7 0%, #fff8f0 100%)" }}>
          <div className="max-w-5xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-black text-gray-900 mb-4">
                Что внутри гайда? 📖
              </h2>
              <p className="text-gray-600 text-xl">74 страницы готового контента для твоего блога</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {[
                {
                  emoji: "💅",
                  title: "Маникюр",
                  items: ["Идеи постов о дизайнах", "Сторис до/после", "Reels с процессом", "Тексты об услугах"],
                },
                {
                  emoji: "🥀",
                  title: "Брови",
                  items: ["Контент про формы бровей", "Уход после процедуры", "Посты с результатами", "Привлечение клиентов"],
                },
                {
                  emoji: "✨",
                  title: "Ресницы",
                  items: ["Разборы эффектов", "Сторис с отзывами", "Видео с результатом", "Тексты-продажники"],
                },
                {
                  emoji: "💄",
                  title: "Макияж",
                  items: ["Тренды сезона", "Туториалы для блога", "Истории трансформаций", "Посты с советами"],
                },
              ].map((section, i) => (
                <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-pink-100 card-hover">
                  <div className="text-4xl mb-3">{section.emoji}</div>
                  <h3 className="font-black text-gray-900 text-lg mb-3">{section.title}</h3>
                  <ul className="space-y-2">
                    {section.items.map((item, j) => (
                      <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                        <span className="text-pink-400 mt-0.5">✓</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {/* Sections */}
            <div className="bg-white rounded-3xl p-8 shadow-sm border border-pink-100">
              <h3 className="font-black text-gray-900 text-2xl mb-6 text-center">Структура гайда</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { num: "01", title: "Введение и система", desc: "Как работает контент-план и как использовать его максимально эффективно" },
                  { num: "02", title: "5 контент-пилларов", desc: "Система чередования типов контента, чтобы аудитория не уставала" },
                  { num: "03", title: "30 готовых дней", desc: "Каждый день расписан: тема, текст, хэштеги, идея для Reels/Stories" },
                  { num: "04", title: "Хэштеги по нишам", desc: "Отдельные наборы для маникюра, бровей, ресниц и макияжа" },
                  { num: "05", title: "Идеи для Reels", desc: "10+ вирусных форматов, которые привлекают новую аудиторию" },
                  { num: "06", title: "Шаблоны Stories", desc: "Готовые сценарии для интерактивных сторис с вовлечением" },
                ].map((item, i) => (
                  <div key={i} className="flex gap-4 p-4 rounded-xl hover:bg-pink-50 transition">
                    <div className="text-3xl font-black text-pink-200 flex-shrink-0">{item.num}</div>
                    <div>
                      <div className="font-bold text-gray-900">{item.title}</div>
                      <div className="text-sm text-gray-600">{item.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* WHO IS IT FOR */}
        <section className="py-20 bg-white">
          <div className="max-w-5xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-black text-gray-900 mb-4">
                Для кого этот гайд? 🎯
              </h2>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-green-600 mb-4 flex items-center gap-2">
                  <span className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600">✓</span>
                  Тебе подойдёт, если ты:
                </h3>
                {[
                  "Мастер маникюра, педикюра или nail-дизайна",
                  "Бровист или мастер по ресницам",
                  "Визажист или мастер по макияжу",
                  "Только начинаешь вести соцсети",
                  "Ведёшь блог, но не знаешь что писать",
                  "Хочешь привлекать клиентов через Instagram/ВКонтакте",
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <span className="text-green-500 mt-0.5 flex-shrink-0">✓</span>
                    <span className="text-gray-700">{item}</span>
                  </div>
                ))}
              </div>

              <div className="gradient-card rounded-3xl p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  После гайда ты сможешь:
                </h3>
                <div className="space-y-4">
                  {[
                    { emoji: "📅", text: "Публиковать контент каждый день без стресса" },
                    { emoji: "📈", text: "Получать новых подписчиков и клиентов из блога" },
                    { emoji: "⏰", text: "Экономить часы времени на придумывание постов" },
                    { emoji: "💰", text: "Превратить соцсети в реальный источник дохода" },
                    { emoji: "🏆", text: "Выглядеть профессионально и экспертно в своей нише" },
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <span className="text-2xl">{item.emoji}</span>
                      <span className="text-gray-700">{item.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* REVIEWS */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-5xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-black text-gray-900 mb-4">
                Что говорят бьюти-мастера ❤️
              </h2>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  name: "Анастасия К.",
                  role: "Мастер маникюра",
                  text: "Раньше тратила по 2 часа на придумывание одного поста. Теперь открываю гайд — и всё готово. За месяц пришло 15 новых клиентов!",
                  stars: 5,
                  emoji: "💅",
                },
                {
                  name: "Юлия М.",
                  role: "Бровист",
                  text: "Наконец-то мой блог стал системным! Хэштеги реально работают, охваты выросли в 3 раза. Рекомендую каждому бьюти-мастеру.",
                  stars: 5,
                  emoji: "🥀",
                },
                {
                  name: "Марина Р.",
                  role: "Мастер по ресницам",
                  text: "Контент-план — лучшее, что случилось с моим аккаунтом. Идеи для Reels особенно огонь! Один ролик набрал 50k просмотров.",
                  stars: 5,
                  emoji: "✨",
                },
                {
                  name: "Екатерина Л.",
                  role: "Визажист",
                  text: "Купила и не пожалела. За 1499 рублей получила месяц готового контента. Это просто спасение для занятого мастера!",
                  stars: 5,
                  emoji: "💄",
                },
                {
                  name: "Дарья В.",
                  role: "Nail-художник",
                  text: "Очень подробный и понятный гайд. Тексты уже написаны, остаётся только добавить свои фото. Экономит кучу времени и сил.",
                  stars: 5,
                  emoji: "🎨",
                },
                {
                  name: "Ольга Т.",
                  role: "Мастер комплексного ухода",
                  text: "Наконец-то я веду блог без стресса! Открываю гайд утром — и знаю, что публиковать весь день. Спасибо огромное!",
                  stars: 5,
                  emoji: "💆",
                },
              ].map((review, i) => (
                <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 card-hover">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center text-2xl"
                      style={{ background: "linear-gradient(135deg, #ff2d8a20, #ff6b6b20)" }}>
                      {review.emoji}
                    </div>
                    <div>
                      <div className="font-bold text-gray-900">{review.name}</div>
                      <div className="text-sm text-gray-500">{review.role}</div>
                    </div>
                  </div>
                  <div className="text-yellow-400 mb-3">{"★".repeat(review.stars)}</div>
                  <p className="text-gray-700 text-sm leading-relaxed">{review.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* REFERRAL */}
        <section className="py-20" style={{ background: "linear-gradient(135deg, #fff0f7, #fff8f0)" }}>
          <div className="max-w-4xl mx-auto px-4 text-center">
            <div className="text-5xl mb-4">🤝</div>
            <h2 className="text-4xl font-black text-gray-900 mb-4">
              Зарабатывай, рекомендуя!
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Поделись гайдом с подругами и коллегами — получай{" "}
              <strong className="text-pink-600">45% от каждой продажи</strong> по
              твоей реферальной ссылке
            </p>

            <div className="grid md:grid-cols-3 gap-6 mb-10">
              {[
                {
                  step: "1",
                  emoji: "💳",
                  title: "Купи гайд",
                  desc: "После покупки ты получаешь личную реферальную ссылку в кабинете",
                },
                {
                  step: "2",
                  emoji: "📤",
                  title: "Поделись ссылкой",
                  desc: "Отправь ссылку подругам, в чаты мастеров, опубликуй в блоге",
                },
                {
                  step: "3",
                  emoji: "💰",
                  title: "Получи 674 ₽",
                  desc: "За каждую покупку по твоей ссылке — 45% от цены = 674 ₽",
                },
              ].map((item, i) => (
                <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-pink-100 relative">
                  <div className="absolute -top-3 -left-3 w-8 h-8 bg-gradient-to-br from-pink-500 to-red-400 rounded-full flex items-center justify-center text-white font-black text-sm">
                    {item.step}
                  </div>
                  <div className="text-4xl mb-3">{item.emoji}</div>
                  <h3 className="font-black text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-600 text-sm">{item.desc}</p>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm border border-pink-100 inline-block mb-8">
              <div className="text-3xl font-black text-gray-900">
                Цена гайда: <span className="text-gray-900">1 499 ₽</span>
              </div>
              <div className="text-xl text-pink-600 font-bold mt-1">
                Твой заработок с реферала: <span className="text-2xl">674 ₽</span>
              </div>
              <div className="text-gray-500 text-sm mt-1">Порекомендуй 3 подругам — окупишь свою покупку с прибылью!</div>
            </div>

            <div>
              <button
                onClick={openModal}
                className="btn-primary text-white font-bold px-10 py-5 rounded-2xl text-xl shadow-lg"
              >
                Купить и получить реферальную ссылку →
              </button>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-20 bg-white">
          <div className="max-w-3xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-black text-gray-900 mb-4">
                Частые вопросы 🙋‍♀️
              </h2>
            </div>
            <div className="space-y-4">
              {[
                {
                  q: "Как я получу гайд после оплаты?",
                  a: "Сразу после успешной оплаты на твой email придёт ссылка для скачивания PDF. Также доступ появится в личном кабинете на сайте.",
                },
                {
                  q: "На каком формате гайд?",
                  a: "Гайд — это PDF файл на 74 страницы. Открывается на любом устройстве: телефон, планшет, компьютер. Скачивается один раз и остаётся навсегда.",
                },
                {
                  q: "Подходит ли гайд для новичков?",
                  a: "Да! Гайд написан максимально просто и понятно. Даже если ты только начинаешь вести блог — всё будет понятно с первых страниц.",
                },
                {
                  q: "Как работает реферальная система?",
                  a: "После покупки ты получаешь личную реферальную ссылку. Когда кто-то покупает гайд по твоей ссылке, тебе начисляется 45% от стоимости — это 674 ₽. Деньги выплачиваются на твои реквизиты.",
                },
                {
                  q: "Могу ли я вернуть деньги?",
                  a: "Поскольку это цифровой продукт (PDF), мы не делаем возвраты после скачивания. Но если возникли технические проблемы с доступом — напиши нам, обязательно поможем.",
                },
                {
                  q: "Для каких соцсетей подходит контент?",
                  a: "Контент-план универсальный — подходит для Instagram, ВКонтакте, Telegram-каналов. Форматы Reels также подходят для TikTok и YouTube Shorts.",
                },
              ].map((item, i) => (
                <FAQItem key={i} question={item.q} answer={item.a} />
              ))}
            </div>
          </div>
        </section>

        {/* FINAL CTA */}
        <section className="py-24 gradient-hero text-white text-center">
          <div className="max-w-3xl mx-auto px-4">
            <div className="text-6xl mb-6">💅✨</div>
            <h2 className="text-4xl md:text-5xl font-black mb-6">
              Хватит мучиться с контентом!
            </h2>
            <p className="text-xl opacity-90 mb-4 max-w-xl mx-auto">
              Один раз купи гайд — и целый месяц знай, что постить каждый день
            </p>
            <p className="text-lg opacity-80 mb-10">
              74 страницы готового контента для бьюти-мастера ждут тебя 👇
            </p>

            <button
              onClick={openModal}
              className="bg-white text-pink-600 font-black px-12 py-6 rounded-2xl text-2xl shadow-2xl hover:shadow-3xl hover:scale-105 transition-all duration-300"
            >
              Купить за 1 499 ₽ →
            </button>

            <div className="mt-6 flex flex-wrap justify-center gap-6 text-sm opacity-80">
              <span>✓ Мгновенный доступ после оплаты</span>
              <span>✓ PDF навсегда</span>
              <span>✓ Реферальная программа 45%</span>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-gray-900 text-gray-400 py-10">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <div className="text-2xl mb-3">💅</div>
          <div className="font-bold text-white text-lg mb-2">BeautyContent</div>
          <div className="text-sm mb-4">30-дневный контент-план для бьюти-мастера</div>
          <div className="flex justify-center gap-6 text-sm mb-6">
            <a href="/dashboard" className="hover:text-white transition">Личный кабинет</a>
            <span className="text-gray-600">|</span>
            <span>© 2025 BeautyContent</span>
          </div>
          <div className="text-xs text-gray-600 max-w-2xl mx-auto">
            Продажа цифровых продуктов. Цифровой товар предоставляется в момент оплаты. Возврат после скачивания не производится.
          </div>
        </div>
      </footer>
    </>
  );
}

function FAQItem({ question, answer }: { question: string; answer: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border border-gray-100 rounded-2xl overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full text-left px-6 py-5 flex items-center justify-between gap-4 hover:bg-pink-50 transition"
      >
        <span className="font-semibold text-gray-900">{question}</span>
        <span className="text-pink-500 text-xl flex-shrink-0">{open ? "−" : "+"}</span>
      </button>
      {open && (
        <div className="px-6 pb-5 text-gray-600 leading-relaxed border-t border-gray-50">
          <div className="pt-4">{answer}</div>
        </div>
      )}
    </div>
  );
}

export default function Page() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-white" />}>
      <HomePage />
    </Suspense>
  );
}
