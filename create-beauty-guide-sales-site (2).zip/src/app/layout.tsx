import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "30-дневный контент-план для бьюти-мастера | PDF гайд",
  description:
    "Готовые посты, хэштеги, идеи для Reels и Stories. 74 страницы контента для мастеров маникюра, бровистов, лешмейкеров и визажистов. Купить за 1499₽",
  openGraph: {
    title: "30-дневный контент-план для бьюти-мастера",
    description:
      "Готовые посты, хэштеги, идеи для Reels и Stories — всё уже продумано за тебя!",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-white text-gray-900 antialiased" style={{ fontFamily: "Inter, sans-serif" }}>
        {children}
      </body>
    </html>
  );
}
